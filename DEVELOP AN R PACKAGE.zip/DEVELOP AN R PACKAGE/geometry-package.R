#' Geometry package: perimeter, circumference, and area calculations
#'
#' @docType package
#' @name geometry
#'
#' @importFrom stats mean
#'

#' @importFrom stats sum

#' @importFrom stats pi
